﻿# BÀI LÀM – ÔN TẬP NGÀY 2

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#b%C3%A0i-l%C3%A0m--%C3%B4n-t%E1%BA%ADp-ng%C3%A0y-2)

-   Họ tên: Nguyễn Hoàng Trí Nhân
-   Lớp: CNTT2
-   Link repository:
-   Hệ điều hành (Windows/macOS): Windows**

## Bài 1. Lọc log thủ công

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#b%C3%A0i-1-l%E1%BB%8Dc-log-th%E1%BB%A7-c%C3%B4ng)

### Lệnh đã chạy

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#l%E1%BB%87nh-%C4%91%C3%A3-ch%E1%BA%A1y)

gc logs/access.log | sls "Error" | Add-content -Path logs/error_report.txt

### 2 dòng lỗi đầu tiên trong error_report.txt

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#2-d%C3%B2ng-l%E1%BB%97i-%C4%91%E1%BA%A7u-ti%C3%AAn-trong-error_reporttxt)

```
2025-10-18 08:17:59 [ERROR] Khong tim thay trang /lich-thi (404)
2025-10-18 08:25:55 [ERROR] Het thoi gian cho (timeout)


```

## Bài 2. Đếm bằng pipeline

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#b%C3%A0i-2-%C4%91%E1%BA%BFm-b%E1%BA%B1ng-pipeline)

### Lệnh

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#l%E1%BB%87nh)

sls "warning" -Path logs/access.log | Measure-Object -Line
sls "error" logs/payment.log | Measure-Object -Line

### Kết quả đếm (Windows: giá trị Count; macOS: con số in ra)

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#k%E1%BA%BFt-qu%E1%BA%A3-%C4%91%E1%BA%BFm-windows-gi%C3%A1-tr%E1%BB%8B-count-macos-con-s%E1%BB%91-in-ra)

```
WARNING trong access.log: 4
ERROR trong payment.log : 3

```

## Bài 3. Chạy script auto_warning (.ps1 hoặc .sh)

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#b%C3%A0i-3-ch%E1%BA%A1y-script-auto_warning-ps1-ho%E1%BA%B7c-sh)

### Lệnh chạy (Windows: nếu dùng Phụ lục 2 thì ghi cả 2 lệnh)

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#l%E1%BB%87nh-ch%E1%BA%A1y-windows-n%E1%BA%BFu-d%C3%B9ng-ph%E1%BB%A5-l%E1%BB%A5c-2-th%C3%AC-ghi-c%E1%BA%A3-2-l%E1%BB%87nh)

./auto_warning.ps1

### Nội dung file logs/warning_report.txt

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#n%E1%BB%99i-dung-file-logswarning_reporttxt)

```
=== CANH BAO THANH TOAN ===

2025-10-18 09:19:13 [WARNING] Cong thanh toan phan hoi cham
2025-10-18 09:28:16 [WARNING] Nhieu lan nhap sai ma OTP
2025-10-18 09:43:01 [WARNING] So du vi gan bang hoc phi
2025-10-18 09:46:22 [WARNING] So du vi gan bang hoc phi
2025-10-18 09:49:43 [WARNING] So du vi gan bang hoc phi




```

## Bài 4. Báo cáo tổng hợp

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#b%C3%A0i-4-b%C3%A1o-c%C3%A1o-t%E1%BB%95ng-h%E1%BB%A3p)

### Các lệnh đã chạy

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#c%C3%A1c-l%E1%BB%87nh-%C4%91%C3%A3-ch%E1%BA%A1y)

"=== TONG HOP ACCESS LOG ===" | set-content  -Path ./logs/tong_hop_ngay2.txt 
 sls "error" logs/access.log | foreach-object { $_.Line } | add-content logs/tong_hop_ngay2.txt
(sls "warning" logs/payment.log | Measure-Object -Line).lines | add-content logs/tong_hop_ngay2.txt

### Nội dung file logs/tong_hop_ngay2.txt

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#n%E1%BB%99i-dung-file-logstong_hop_ngay2txt)

```
=== TONG HOP ACCESS LOG ===
2025-10-18 08:17:59 [ERROR] Khong tim thay trang /lich-thi (404)
2025-10-18 08:25:55 [ERROR] Het thoi gian cho (timeout)
2025-10-18 08:33:51 [ERROR] Ket noi may chu du lieu that bai
2025-10-18 08:37:19 [ERROR] Ket noi may chu du lieu that bai
2025-10-18 08:49:43 [ERROR] Het thoi gian cho (timeout)
2025-10-18 08:53:11 [ERROR] Het thoi gian cho (timeout)
5



```

## Bài 5. Câu hỏi ngắn

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#b%C3%A0i-5-c%C3%A2u-h%E1%BB%8Fi-ng%E1%BA%AFn)

**a)**  `>`  ghi đè nội dung cũ, còn  `>>`  nối nội dung mới vào cuối file.

**b)**  File chỉ còn các dòng  `ERROR`  của lệnh thứ hai, nội dung cũ bị mất.

**c)**  Đường dẫn tương đối giúp dễ di chuyển, chia sẻ dự án và chạy script trên nhiều máy tính.

## Tự chấm (điền sau khi có đáp án)

[](https://github.com/Baolam070108/HN-KS26-CNTT2_Nhap-mon-CNTT_On-Tap-Ngay2/blob/main/starter-kit/bai_lam_ngay2.md#t%E1%BB%B1-ch%E1%BA%A5m-%C4%91i%E1%BB%81n-sau-khi-c%C3%B3-%C4%91%C3%A1p-%C3%A1n)

-   **Điểm tự chấm:**  ..../100
-   **Lỗi mình đã mắc và cách sửa:**
